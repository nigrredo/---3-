﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NatalochkaNeSovsemNoTop
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		//char[,] array = new char[10, 10];
		private char[,] fillArr()
		{
			char[,] arr = new char[5, 5];

			for (int i = 0; i < 5; i++)
			{
				for (int j = 0; j < 5; j++)
				{

					if ((i - j) > 2)
					{
						arr[i, j] = 'O';
					}
					else if (((j + 2) % 3 == 0) && (i % 2 == 0))
					{
						arr[i, j] = 'F';
					}
					else if ((i - 1) % 2 == 0 && (j % 3 == 0))
					{
						arr[i, j] = 'P';
					}
					else
					{
						arr[i, j] = 'K';
					}
				}
			}
			return arr;
		}


		private void Button1_Click(object sender, EventArgs e)
		{
			char[,] arr = fillArr();
			string choice = listBox1.GetItemText(listBox1.SelectedItem);
			if (textBox1.Text.Length != 1)
			{
				textBox4.Text = "Значение  должно быть символом";
			}
			else
			{
				char input = Convert.ToChar(textBox1.Text.ToUpper());
				try
				{


					int count = 0;

					if (choice == "indirect")
					{
						for (int i = 5 - 1; i >= 0; i--)
						{
							if (arr[i, 4 - i] == input)
							{
								count++;
							}
						}
						textBox4.Text = count.ToString();
					}
					else if (choice == "main")
					{
						for (int i = 0; i < 5; i++)
						{
							if (arr[i, i] == input)
							{
								count++;
							}
						}
						textBox4.Text = count.ToString();
					}
					else
					{
						textBox4.Text = "Вы должны выбрать ";
					}

				}
				catch (FormatException ex)
				{
					textBox4.Text = "Position must be string";
				}
			}

		}

		private void Button2_Click(object sender, EventArgs e)
		{
			listview.Items.Clear();
			char[,] arr = fillArr();
			//int counterOfArraylist = arr.Count;
			string[] str = new string[5];
			for (int i = 0; i < 5; i++)
			{
				for (int j = 0; j < 5; j++)
				{
					str[i] += (arr[i, j].ToString());
				}
				listview.Items.Add(new ListViewItem(str[i]));
				//str[i] = mcarraylist[i].ToString();

			}
			//    listview.Items.Add(new ListViewItem(str));
		}

		private void TextBox4_TextChanged(object sender, EventArgs e)
		{

		}

		private void Label4_Click(object sender, EventArgs e)
		{

		}
	}
}

